require "byebug"

# def zip(*arr)
#     new_arr = []
#     # arr.each_with_index do |el , i|
#     #     other.each_with_index do |el2, i2|
#     #         if i2 > i
#     #             new_arr << [el,el2]
#     #         end
#     #     end
#     # end
#     # new_arr
    
#     # arr.each_index do |i|
#     #     tem = other[i]
#     #         new_arr << [arr[i],tem[i]]
#     # end
#     # new_arr

#     arr.each do |ele|
#         new_arr << ele
#     end
#     new_arr
# end

# p zip(array_1, array_2, array_3)


def zip(*arr)
    out_length = arr.length
    sub_length = arr[0].length
    answer = Array.new (sub_length){Array.new(out_length)}
    (0...out_length).each do |out_i|
        (0...sub_length).each do |in_i|
            answer[in_i][out_i] = arr[out_i][in_i]  
        end
    end
    answer
end


def prizz_proc(arr, prc1, prc2)

    new_arr=[]
    arr.each do |ele|
        if prc1.call(ele) && !prc2.call(ele)
            new_arr << ele
        elsif !prc1.call(ele) && prc2.call(ele)
            new_arr << ele
        end
    end
    new_arr

end

     
def zany_zip(*arr)    
    out_length = arr.length
    sub_length = 0
    arr.each do |ar|
        sub_length = ar.length if ar.length > sub_length
    end
    answer = Array.new (sub_length){Array.new(out_length)}
    (0...out_length).each do |out_i|
        (0...sub_length).each do |in_i|
            answer[in_i][out_i] = arr[out_i][in_i]  
        end
    end
    answer
end

def maximum(arr, &prc)
    new_arr = []
    arr.each do |el|
        new_arr << prc.call(el)
    end
    max_index = 0
    max = 0
    new_arr.each_with_index do |el, i| 
        if  el > max
            max = el
            max_index = i
        elsif el == max
            max_index = i
        end
    end
    arr[max_index]
end

def my_group_by(arr, &prc)
    hash = {}
    arr.each do |ele|
         if hash.has_key?(prc.call(ele))
            hash[prc.call(ele)] << ele
        else
            hash[prc.call(ele)] = [ele]
        end
    end
    # arr.each do |ele|
    #     if hash.has_key?(prc.call(ele))
    #         hash[prc.call(ele)] << ele
    #     end
    # end
    hash
end


# def max_tie_breaker(arr, prc, &block)
#     new_arr = []
#     arr.each do |el|
#         new_arr << block.call(el)
#     end
#     max_index = 0
#     max = 0
#     new_arr.each_with_index do |el, i| 
#         if  el > max
#             max = el
#             max_index = i
#         elsif el == max 
#             if prc.call(el) > prc.call(max)
#                 max_index = i
#             end
#         end
#     end
#     arr[max_index]
# end

def max_tie_breaker(arr, prc, &block)
    return nil if arr.empty?
    max = arr.first
    arr.each do |el|
        result_el = prc.call(el)
        result_max = prc.call(max)
        if result_el > result_max
            max = el
        elsif result_el == result_max && prc.call(el) > prc.call(max)
            max = el
        end
    end
    max
end
